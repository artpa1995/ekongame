<?php

class Product extends Model{
     
}