<?php
// use Users;
class Admin extends Model{

    

}