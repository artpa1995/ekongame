<?php
class Post extends Model{

    public function getPosts($userId = null){

    }

}