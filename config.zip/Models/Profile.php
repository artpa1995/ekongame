<?php

class Profile extends Model{
     
}