<?php

class Orders extends Model{
     
}