<?php

class errorController extends Controller {

    public function errorAction()
    {
      $this->render("error-404");  
    }
 
  
  }
  





