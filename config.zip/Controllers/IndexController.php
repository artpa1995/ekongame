<?php
class IndexController extends Controller {

    public function indexAction(){

        $this->render("index");
        
    }
}