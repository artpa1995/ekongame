
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title> Products </title>

    <!-- BOOTSTRAP STYLES-->
    <link href="<?php echo App::url('assets_products/css/style.css') ?>" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
     



</head>


<body>
    


   