<!-- <a href="<?php //echo App::url('users/register') ?>">Registration</a>
<a href="<?php //echo App::url('users/login') ?>">Login</a>
<a href="<?php // echo App::url('post/create') ?>">post</a>
<a href="<?php //echo App::url('users/confirmation') ?>">confirmation</a>
<a href="<?php //echo App::url('admin/page') ?>">admin</a> -->